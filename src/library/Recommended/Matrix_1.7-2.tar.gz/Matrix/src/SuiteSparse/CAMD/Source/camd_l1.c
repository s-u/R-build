//------------------------------------------------------------------------------
// CAMD/Source/camd_l1.c: int64_t version of camd_1
//------------------------------------------------------------------------------

// CAMD, Copyright (c) 2007-2022, Timothy A. Davis, Yanqing Chen, Patrick R.
// Amestoy, and Iain S. Duff.  All Rights Reserved.
// SPDX-License-Identifier: BSD-3-clause

//------------------------------------------------------------------------------

#define DLONG
#include "camd_1.c"

