//------------------------------------------------------------------------------
// CAMD/Source/camd_l_order.c: int64_t version of camd_order
//------------------------------------------------------------------------------

// CAMD, Copyright (c) 2007-2022, Timothy A. Davis, Yanqing Chen, Patrick R.
// Amestoy, and Iain S. Duff.  All Rights Reserved.
// SPDX-License-Identifier: BSD-3-clause

//------------------------------------------------------------------------------

#define DLONG
#include "camd_order.c"

